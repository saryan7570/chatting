import { Component, OnInit } from '@angular/core';
import { ServicService, Employee } from '../servic.service';
//import { runInThisContext } from 'vm';

@Component({
  selector: 'app-adddata',
  templateUrl: './adddata.component.html',
  styleUrls: ['./adddata.component.css']
})
export class AdddataComponent implements OnInit {

  service  : ServicService;
  emp : Employee[] = [];


  constructor(service : ServicService) {
    this.service = service;
   }

  ngOnInit() {
    this.emp = this.service.getData();
  }

  add(data : any){
    console.log(data);
    let fname= data.fname
     let lname = data.lname
     let  phone = data.phone
     let email = data.email
     let gender = data.gender
     let password = data.password
    let check = this.service.add(fname, lname, phone, email, gender, password);
    check.subscribe((data)=>{
      console.log("created");
    },(error)=>{
      console.log("Account not Created")
    })
  }

}
