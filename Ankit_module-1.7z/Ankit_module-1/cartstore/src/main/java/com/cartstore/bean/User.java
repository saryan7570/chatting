package com.cartstore.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CartStore")
public class User {
	
	
	private String fname;
	
	private String lname;
	
	@Id
	
	private String mobileNo;

	private String emailId;
	
	private String gender;
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	private String password;

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(String fname, String lname, String mobileNo, String emailId, String gender, String password) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.mobileNo = mobileNo;
		this.emailId = emailId;
		this.password = password;
		this.gender=gender;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "User [fname=" + fname + ", lname=" + lname + ", mobileNo=" + mobileNo + ", emailId=" + emailId
				+ ", gender=" +gender +" , password=" + password + "]";
	}

	
	

}
