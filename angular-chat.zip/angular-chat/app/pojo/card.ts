
export class Card
{
    cardNumber:number;
	cardHolderName:string;
	expiryDate:Date;
	cvv:number;
    Balance:LongRange;
    pinNumber:number;
	
}