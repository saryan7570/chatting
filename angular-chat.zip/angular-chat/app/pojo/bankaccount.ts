
export class BankAccount {
    accountNumber:number;
    customerName:string;		
    userName:string;
    userPassword:string;
    balance:number;
} 