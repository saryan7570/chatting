# UiRating

Component for output rating.
